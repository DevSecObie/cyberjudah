---
slug: blindness
title: "Blindness"
refs: 12
tags: [precept]
---

> [!info]- Generated
> This note is built from the source data by `scripts/build_vault.py` and is overwritten on every run. Put your own notes in a separate file and link here.


# Blindness

[[Precepts index]] · [Home](/)

- [[Romans 11#^v8|Romans 11:8]]
- [[Romans 11#^v25|Romans 11:25]]
- [[Deuteronomy 28#^v28|Deuteronomy 28:28]]  taught in [[Deuteronomy 27-30 Study Notes|Deuteronomy 27-30]]
- [[Deuteronomy 29#^v4|Deuteronomy 29:4]]  taught in [[Deuteronomy 27-30 Study Notes|Deuteronomy 27-30]]
- [[Ephesians 4#^v18|Ephesians 4:18]]
- [[2 Corinthians 3#^v14|2 Corinthians 3:14]]
- [[Isaiah 59#^v10|Isaiah 59:10]]
- [[Mark 8#^v18|Mark 8:18]]
- [[Ezekiel 12#^v2|Ezekiel 12:2]]
- [[Matthew 13#^v15|Matthew 13:15]]
- [[Psalms 119#^v18|Psalms 119:18]]
- [[Jeremiah 5#^v21|Jeremiah 5:21]]
