---
slug: greatest-commandments
title: "Greatest Commandments"
refs: 7
tags: [precept]
---

> [!info]- Generated
> This note is built from the source data by `scripts/build_vault.py` and is overwritten on every run. Put your own notes in a separate file and link here.


# Greatest Commandments

[[Precepts index]] · [Home](/)

- [[Deuteronomy 6#^v5|Deuteronomy 6:5]]  taught in [[Deuteronomy 3-6 Study Notes|Deuteronomy 3-6]]
- [[Leviticus 19#^v18|Leviticus 19:18]]  taught in [[Leviticus 18-21 Study Notes|Leviticus 18-21]]
- [[Mark 12#^v30|Mark 12:30]]
- [[Mark 12#^v31|Mark 12:31]]
- [[Matthew 22#^v37|Matthew 22:37]]
- [[Matthew 22#^v39|Matthew 22:39]]
- [[Luke 10#^v27|Luke 10:27]]
