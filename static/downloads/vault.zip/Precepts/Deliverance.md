---
slug: deliverance
title: "Deliverance"
refs: 4
tags: [precept]
---

> [!info]- Generated
> This note is built from the source data by `scripts/build_vault.py` and is overwritten on every run. Put your own notes in a separate file and link here.


# Deliverance

[[Precepts index]] · [Home](/)

- [[Obadiah 1#^v17|Obadiah 1:17]]
- [[Joel 2#^v32|Joel 2:32]]
- [[Psalms 44#^v4|Psalms 44:4]]
- [[Luke 4#^v18|Luke 4:18]]
