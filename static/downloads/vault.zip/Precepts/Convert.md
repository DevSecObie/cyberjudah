---
slug: convert
title: "Convert"
refs: 4
tags: [precept]
---

> [!info]- Generated
> This note is built from the source data by `scripts/build_vault.py` and is overwritten on every run. Put your own notes in a separate file and link here.


# Convert

[[Precepts index]] · [Home](/)

- [[Psalms 19#^v7|Psalms 19:7]]
- [[Matthew 13#^v15|Matthew 13:15]]
- [[Matthew 18#^v3|Matthew 18:3]]
- [[Acts 3#^v19|Acts 3:19]]
