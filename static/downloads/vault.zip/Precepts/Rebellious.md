---
slug: rebellious
title: "Rebellious"
refs: 4
tags: [precept]
---

> [!info]- Generated
> This note is built from the source data by `scripts/build_vault.py` and is overwritten on every run. Put your own notes in a separate file and link here.


# Rebellious

[[Precepts index]] · [Home](/)

- [[Zechariah 7#^v11|Zechariah 7:11]]
- [[Isaiah 30#^v1|Isaiah 30:1]]
- [[Ezekiel 3#^v7|Ezekiel 3:7]]
- [[Jeremiah 5#^v23|Jeremiah 5:23]]
