---
slug: poor
title: "Poor"
refs: 8
tags: [precept]
---

> [!info]- Generated
> This note is built from the source data by `scripts/build_vault.py` and is overwritten on every run. Put your own notes in a separate file and link here.


# Poor

[[Precepts index]] · [Home](/)

- [[Ecclesiastes 5#^v8|Ecclesiastes 5:8]]
- [[1 Samuel 2#^v8|1 Samuel 2:8]]  taught in [[1 Samuel 1-3 Study Notes|1 Samuel 1-3]]
- [[Psalms 10#^v2|Psalms 10:2]]
- [[Job 36#^v15|Job 36:15]]
- [[Isaiah 14#^v32|Isaiah 14:32]]
- [[Matthew 5#^v3|Matthew 5:3]]
- [[Luke 4#^v18|Luke 4:18]]
- [[Revelation 2#^v9|Revelation 2:9]]
