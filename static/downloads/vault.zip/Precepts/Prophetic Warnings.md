---
slug: prophetic-warnings
title: "Prophetic Warnings"
refs: 4
tags: [precept]
---

> [!info]- Generated
> This note is built from the source data by `scripts/build_vault.py` and is overwritten on every run. Put your own notes in a separate file and link here.


# Prophetic Warnings

[[Precepts index]] · [Home](/)

- [[2 Esdras 15#^v5|2 Esdras 15:5]]
- [[Jeremiah 28#^v8|Jeremiah 28:8]]
- [[Matthew 24#^v7|Matthew 24:7]]
- [[Revelation 6#^v8|Revelation 6:8]]
