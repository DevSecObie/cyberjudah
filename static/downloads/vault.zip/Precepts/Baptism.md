---
slug: baptism
title: "Baptism"
refs: 7
tags: [precept]
---

> [!info]- Generated
> This note is built from the source data by `scripts/build_vault.py` and is overwritten on every run. Put your own notes in a separate file and link here.


# Baptism

[[Precepts index]] · [Home](/)

- [[1 Peter 3#^v21|1 Peter 3:21]]
- [[1 Corinthians 10#^v2|1 Corinthians 10:2]]
- [[Jeremiah 2#^v22|Jeremiah 2:22]]
- [[Matthew 3#^v6|Matthew 3:6]]
- [[Matthew 3#^v11|Matthew 3:11]]
- [[John 3#^v30|John 3:30]]
- [[John 4#^v2|John 4:2]]
