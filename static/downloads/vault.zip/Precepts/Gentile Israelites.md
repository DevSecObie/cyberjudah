---
slug: gentile-israelites
title: "Gentile Israelites"
refs: 9
tags: [precept]
---

> [!info]- Generated
> This note is built from the source data by `scripts/build_vault.py` and is overwritten on every run. Put your own notes in a separate file and link here.


# Gentile Israelites

[[Precepts index]] · [Home](/)

- [[Romans 9#^v25|Romans 9:25]]
- [[Hosea 1#^v10|Hosea 1:10]] **(key)**
- [[Galatians 3#^v8|Galatians 3:8]]
- [[Ephesians 2#^v11|Ephesians 2:11]]
- [[1 Corinthians 12#^v2|1 Corinthians 12:2]]
- [[Matthew 4#^v15|Matthew 4:15]]
- [[2 Maccabees 6#^v9|2 Maccabees 6:9]]
- [[John 7#^v35|John 7:35]]
- [[Acts 10#^v45|Acts 10:45]]
